package ar.edu.centro8.desarrollo.proyectosbon2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Proyectosbon2Application {

    public static void main(String[] args) {
        SpringApplication.run(Proyectosbon2Application.class, args);
    }
}