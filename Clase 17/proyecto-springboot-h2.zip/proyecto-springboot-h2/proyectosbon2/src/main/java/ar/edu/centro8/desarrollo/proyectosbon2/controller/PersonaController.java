package ar.edu.centro8.desarrollo.proyectosbon2.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import ar.edu.centro8.desarrollo.proyectosbon2.model.Persona;
import ar.edu.centro8.desarrollo.proyectosbon2.repository.jpa.JpaPersonaRepository;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PutMapping;


@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*", methods = {RequestMethod.GET,RequestMethod.POST,RequestMethod.PUT,RequestMethod.DELETE})
public class PersonaController {

    @Autowired
    private JpaPersonaRepository jpaPersonaRepo;

    @GetMapping("/persona/traer")
    public List<Persona> traerPersonas() {
        return jpaPersonaRepo.findAll();
    }

    @GetMapping("/persona/traer/{id}")
    public Optional<Persona> traerUnaPersona(@PathVariable Long id) {
        return jpaPersonaRepo.findById(id);
    }
    

    @PostMapping("/persona/crear")
    public void crearPersona(@RequestBody Persona p) {
        jpaPersonaRepo.save(p);
    }
    

    @DeleteMapping("/persona/borrar/{id}")
    public String borrarUnaPersona(@PathVariable Long id) {
        jpaPersonaRepo.deleteById(id);
        return "persona eliminada correctamente";
    }

    @PutMapping("/persona/actualizar/{id}")
    public String actualizarUnaPersona(@PathVariable Long id, @RequestBody Persona p) {
        Persona personaBuscada = jpaPersonaRepo.findById(id).orElse(null);
        if (personaBuscada != null) {
            personaBuscada.setNombre(p.getNombre());
            personaBuscada.setEdad(p.getEdad());
            jpaPersonaRepo.save(personaBuscada);
        }
        return "Datos de la persona actualizada correctamente";
    }   
        
}
