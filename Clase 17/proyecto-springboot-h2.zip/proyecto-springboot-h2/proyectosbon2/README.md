# Proyectosbon2 - API REST con Spring Boot y H2 (Base de Datos en Memoria)

Este proyecto es una API REST desarrollada con **Spring Boot 3** y **Spring Data JPA**, utilizando **H2 Database** como motor de base de datos relacional **en memoria** (`jdbc:h2:mem:testdb`). Permite realizar operaciones CRUD completas sobre la entidad `Persona`.

Adicionalmente, incluye la consola web de H2 habilitada (`/h2-console`) para consultar y gestionar la base de datos visualmente en tiempo real, así como una colección lista para usar en **Bruno** dentro de la carpeta `bruno/`, configurada con URLs directas a `http://localhost:8080` y con pruebas y asertos automatizados.

---

## 📋 Requisitos Previos

- **Java JDK 17** o superior instalado y configurado en las variables de entorno (`PATH`).
- **Maven** (opcional, ya que se incluye el Maven Wrapper `./mvnw` y `mvnw.cmd`).
- **Navegador Web** (Chrome, Firefox, Edge, etc.) para acceder a la consola web interactiva de H2.
- **Bruno API Client** ([Descargar Bruno](https://www.usebruno.com/)) para ejecutar la colección de pruebas de la API.

---

## ⚙️ Configuración de H2 en Spring Boot

La configuración de la base de datos en memoria y su consola web se encuentra centralizada en `src/main/resources/application.properties`:

```properties
spring.application.name=proyectosbon2

# ===============================================
# Configuración de Base de Datos H2 en Memoria
# ===============================================
spring.datasource.url=jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE
spring.datasource.driverClassName=org.h2.Driver
spring.datasource.username=sa
spring.datasource.password=

# ===============================================
# Configuración de JPA / Hibernate
# ===============================================
spring.jpa.database-platform=org.hibernate.dialect.H2Dialect
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.format_sql=true

# ===============================================
# Configuración de la Consola Web de H2
# ===============================================
spring.h2.console.enabled=true
spring.h2.console.path=/h2-console
spring.h2.console.settings.web-allow-others=false
```

### Explicación de los parámetros clave:
- `jdbc:h2:mem:testdb`: Define la base de datos en memoria llamada `testdb`.
- `DB_CLOSE_DELAY=-1`: Mantiene el contenido de la base de datos en memoria activo durante toda la vida útil de la aplicación, evitando que se destruya al cerrarse las conexiones individuales de los repositorios.
- `spring.jpa.hibernate.ddl-auto=update`: Hibernate crea o actualiza automáticamente las tablas (como `personas`) al iniciar la aplicación.
- `spring.h2.console.enabled=true`: Activa la consola web interactiva de H2.
- `spring.h2.console.path=/h2-console`: Establece la ruta de acceso web a la consola.

---

## 🚀 Cómo Iniciar la Aplicación

1. Abre una terminal en la raíz del proyecto (`proyectosbon2`).
2. Ejecuta el comando según tu sistema operativo:

   - **En Windows (PowerShell o CMD):**
     ```powershell
     .\mvnw.cmd spring-boot:run
     ```

   - **En Linux o macOS:**
     ```bash
     ./mvnw spring-boot:run
     ```

3. La aplicación iniciará en el puerto 8080:
   ```
   http://localhost:8080
   ```

> [!NOTE]
> Al tratarse de una base de datos en memoria (**in-memory**), los datos persisten mientras la aplicación permanezca en ejecución. Al reiniciar o detener la aplicación, la base de datos se recrea vacía de forma limpia.

---

## 🌐 Paso a Paso: Cómo Conectar y Usar la Consola Web de H2

Spring Boot provee una interfaz gráfica web para administrar la base de datos H2 sin necesidad de instalar software externo.

### Paso 1: Abrir la consola en el navegador
Con la aplicación Spring Boot en ejecución, abre tu navegador web e ingresa a la siguiente URL:

👉 **[http://localhost:8080/h2-console](http://localhost:8080/h2-console)**

---

### Paso 2: Configurar los datos de conexión en el formulario de login

Al ingresar verás el formulario de inicio de sesión de H2. Asegúrate de configurar los campos exactamente de la siguiente manera:

| Campo | Valor a colocar | Descripción / Observación |
| :--- | :--- | :--- |
| **Saved Settings** | `Generic H2 (Embedded)` | Configuración predeterminada |
| **Setting Name** | `Generic H2 (Embedded)` | Nombre descriptivo |
| **Driver Class** | `org.h2.Driver` | Driver JDBC de H2 |
| **JDBC URL** | `jdbc:h2:mem:testdb` | ⚠️ **Importante**: Si el navegador autocompleta con `jdbc:h2:~/test`, debes borrarlo y reemplazarlo por `jdbc:h2:mem:testdb` |
| **User Name** | `sa` | Usuario predeterminado |
| **Password** | *(dejar vacío)* | Sin contraseña |

> [!IMPORTANT]
> **El campo `JDBC URL` debe coincidir exactamente con el valor definido en `application.properties`**:  
> `jdbc:h2:mem:testdb`  
> Si dejas el valor por defecto (`jdbc:h2:~/test`), H2 intentará conectarse a otra base de datos en disco y no verás la tabla `personas` generada por la aplicación.

---

### Paso 3: Probar y Conectar
1. *(Opcional)* Haz clic en el botón **Test Connection**. Si todo está bien, verás un mensaje que indica que la conexión fue exitosa (*Test successful*).
2. Haz clic en el botón **Connect**.

---

### Paso 4: Explorar y Consultar los Datos en H2
Una vez dentro de la consola:
1. **Árbol de navegación izquierdo**:
   - Verás la base de datos `TESTDB`.
   - Despliega la tabla **`PERSONAS`** para ver sus columnas: `ID_PERSONA` (clave primaria), `EDAD` y `NOMBRE`.
2. **Editor de consultas SQL (panel superior)**:
   - Haz clic sobre el nombre de la tabla `PERSONAS` en el panel izquierdo para generar automáticamente la consulta, o escribe manualmente:
     ```sql
     SELECT * FROM PERSONAS;
     ```
   - Haz clic en el botón **Run** (o presiona `Ctrl + Enter`).
3. **Panel de resultados (panel inferior)**:
   - Verás los registros devueltos en una tabla interactiva.
   - Si creas o modificas personas desde **Bruno** o **cURL**, vuelve a hacer clic en **Run** para ver reflejados los cambios inmediatamente.
4. Para cerrar la sesión de la consola, haz clic en el icono rojo de desconexión en la esquina superior izquierda.

---

## 📡 Endpoints de la API (`PersonaController`)

Todos los endpoints están mapeados bajo el prefijo `/api/persona` y tienen CORS habilitado para todos los orígenes (`*`).

| Método | Endpoint | Descripción | Body (JSON) | Respuesta Exitosa |
| :--- | :--- | :--- | :--- | :--- |
| **POST** | `http://localhost:8080/api/persona/crear` | Crea una nueva persona | `{"nombre": String, "edad": int}` | `200 OK` (cuerpo vacío) |
| **GET** | `http://localhost:8080/api/persona/traer` | Retorna todas las personas | Ninguno | `200 OK` (`[ {...}, {...} ]`) |
| **GET** | `http://localhost:8080/api/persona/traer/{id}` | Retorna una persona por su ID | Ninguno | `200 OK` (`{ "idPersona": ..., "nombre": ..., "edad": ... }`) |
| **PUT** | `http://localhost:8080/api/persona/actualizar/{id}` | Modifica los datos de una persona | `{"nombre": String, "edad": int}` | `200 OK` (`"Datos de la persona actualizada correctamente"`) |
| **DELETE** | `http://localhost:8080/api/persona/borrar/{id}` | Elimina una persona por su ID | Ninguno | `200 OK` (`"persona eliminada correctamente"`) |

### Estructura de la Entidad `Persona`

```json
{
  "idPersona": 1,
  "nombre": "Juan Perez",
  "edad": 25
}
```

---

## 📂 Colección Bruno (`/bruno`)

La carpeta `bruno/` contiene la colección completa de peticiones listas para importar y usar en Bruno.

> [!NOTE]
> La colección está configurada sin variables de entorno ni `baseUrl`: todas las solicitudes apuntan directamente a `http://localhost:8080`.

### Estructura de Archivos

```
bruno/
├── bruno.json                               # Definición de la colección Bruno
├── 01 - Crear Persona 1.bru                 # POST - Inserta "Juan Perez" (edad 25)
├── 02 - Crear Persona 2.bru                 # POST - Inserta "Maria Gomez" (edad 30)
├── 03 - Traer Todas las Personas.bru        # GET  - Consulta lista completa
├── 04 - Traer Persona por ID.bru            # GET  - Consulta la persona con ID 1
├── 05 - Actualizar Persona.bru              # PUT  - Modifica la persona con ID 1
├── 06 - Traer Persona Actualizada.bru       # GET  - Verifica actualización del ID 1
├── 07 - Borrar Persona.bru                  # DELETE - Elimina la persona con ID 1
└── 08 - Verificar Persona Borrada.bru       # GET  - Comprueba que el ID 1 ya no exista
```

---

## 🧪 Cómo Importar y Ejecutar las Pruebas en Bruno

### Paso 1: Abrir la colección en Bruno
1. Abre **Bruno** en tu equipo.
2. En la pantalla inicial, haz clic en **Open Collection** (o ve al menú: **Collection** > **Open Collection**).
   > [!IMPORTANT]
   > No utilices la opción **Import Collection** (esa opción es para convertir archivos de Postman, Insomnia u OpenAPI y dará error con una colección nativa de Bruno).
3. Selecciona la carpeta **`bruno`** (o directamente la carpeta raíz del proyecto **`proyectosbon2`**).
4. Haz clic en **Open / Seleccionar carpeta**.
5. Verás la colección cargada en la barra lateral con todas las peticiones ordenadas del `01` al `08`.

### Paso 2: Ejecución individual
Puedes hacer clic sobre cualquiera de las peticiones en el panel izquierdo y presionar el botón **Send** (o atajo `Ctrl + Enter` / `Cmd + Enter`) para disparar la solicitud contra el backend.

### Paso 3: Flujo de prueba recomendado (Ciclo de vida completo)

1. **`01 - Crear Persona 1` (POST)**:
   - Envía a "Juan Perez", 25 años.
   - Retorna código HTTP `200`.
2. **`02 - Crear Persona 2` (POST)**:
   - Envía a "Maria Gomez", 30 años.
   - Retorna código HTTP `200`.
3. **`03 - Traer Todas las Personas` (GET)**:
   - Recupera el arreglo JSON con las 2 personas creadas.
   - Valida que la respuesta contenga el listado con status `200`.
4. **`04 - Traer Persona por ID` (GET)**:
   - Consulta el registro con `idPersona = 1`.
   - Valida que contenga los campos `idPersona`, `nombre` y `edad`.
5. **`05 - Actualizar Persona` (PUT)**:
   - Modifica el registro 1 asignándole nombre `"Juan Carlos Perez"` y edad `26`.
   - Valida el mensaje de confirmación `"Datos de la persona actualizada correctamente"`.
6. **`06 - Traer Persona Actualizada` (GET)**:
   - Realiza un GET sobre `/api/persona/traer/1`.
   - Los asertos verifican automáticamente que `nombre === "Juan Carlos Perez"` y `edad === 26`.
7. **`07 - Borrar Persona` (DELETE)**:
   - Elimina la persona con ID 1 enviando DELETE a `/api/persona/borrar/1`.
   - Valida el mensaje de confirmación `"persona eliminada correctamente"`.
8. **`08 - Verificar Persona Borrada` (GET)**:
   - Intenta traer la persona 1 para corroborar que ya no existe (el cuerpo devuelto es `null` / vacío).

### Paso 4: Ejecución automatizada en lote (Collection Runner)
1. En Bruno, haz clic secundario sobre la colección o pulsa en los tres puntos (`...`).
2. Selecciona **Run Collection** (o ve a la pestaña **Runner**).
3. Presiona **Run**.
4. Bruno ejecutará todas las solicitudes en secuencia (`seq: 1` a `seq: 8`), evaluando las aserciones (`assert`) y scripts de prueba (`tests`) automáticamente, mostrando todos los tests en verde (aprobados).

---

## ⚡ Pruebas rápidas mediante cURL (Alternativa por Terminal)

Si deseas probar los endpoints directamente desde una consola de comandos sin abrir la interfaz de Bruno:

```bash
# 1. Crear persona 1
curl -X POST http://localhost:8080/api/persona/crear -H "Content-Type: application/json" -d "{\"nombre\":\"Juan Perez\",\"edad\":25}"

# 2. Crear persona 2
curl -X POST http://localhost:8080/api/persona/crear -H "Content-Type: application/json" -d "{\"nombre\":\"Maria Gomez\",\"edad\":30}"

# 3. Traer todas las personas
curl -X GET http://localhost:8080/api/persona/traer

# 4. Traer persona por ID
curl -X GET http://localhost:8080/api/persona/traer/1

# 5. Actualizar persona
curl -X PUT http://localhost:8080/api/persona/actualizar/1 -H "Content-Type: application/json" -d "{\"nombre\":\"Juan Carlos Perez\",\"edad\":26}"

# 6. Borrar persona
curl -X DELETE http://localhost:8080/api/persona/borrar/1
```
