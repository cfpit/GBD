# Colección de Bruno - Proyecto JPA

Esta carpeta contiene la colección de pruebas de endpoints para la aplicación utilizando **[Bruno](https://www.usebruno.com/)**.

## Cómo usarla en Bruno

1. Abre la aplicación **Bruno**.
2. Selecciona **Open Collection**.
3. Selecciona esta carpeta (`bruno`).
4. Asegúrate de que la aplicación Spring Boot esté ejecutándose en el puerto `8080`.
5. Ejecuta cualquiera de las peticiones directamente (ya tienen la URL fija `http://localhost:8080`).

## Endpoints incluidos

| Método | Endpoint | Descripción | Parámetros / Body |
|--------|----------|-------------|-------------------|
| `GET` | `http://localhost:8080/personas/traer` | Obtener todas las personas | Ninguno |
| `POST` | `http://localhost:8080/personas/crear` | Registrar una nueva persona | JSON Body: `{ "nombre": "...", "edad": ... }` |
| `PUT` | `http://localhost:8080/personas/editar/1` | Modificar datos de una persona | Query params: `id`, `nombre`, `edad` |
| `DELETE` | `http://localhost:8080/personas/borrar/1` | Eliminar una persona por ID | Path param: `id` |
